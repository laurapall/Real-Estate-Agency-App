prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 69163
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>69163
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
null;
wwv_flow_imp.component_end;
end;
/
