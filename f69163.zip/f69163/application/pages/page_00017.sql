prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>69163
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'Selectare imobil'
,p_alias=>'SELECTARE-IMOBIL'
,p_step_title=>'Selectare imobil'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230201224226'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47153136477071536117)
,p_plug_name=>'Selectare camere'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(45516681581063627799)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(47153136675937536119)
,p_name=>'Lista imobilelor'
,p_template=>wwv_flow_imp.id(45516681581063627799)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P_IMOBIL.COD_IMOBIL as COD_IMOBIL,',
'    P_IMOBIL.MARIME as MARIME,',
'    P_IMOBIL.ADRESA_IMOBIL as ADRESA_IMOBIL,',
'    P_IMOBIL.COD_LOCALITATE as COD_LOCALITATE,',
'    P_IMOBIL.COD_TIP_IMOBIL as COD_TIP_IMOBIL,',
'    P_IMOBIL.COD_CAMERE as COD_CAMERE,',
'    P_IMOBIL.PRET_IMOBIL as PRET_IMOBIL,',
'    P_IMOBIL.DATA_AFISARE as DATA_AFISARE ',
' from P_IMOBIL P_IMOBIL',
'where cod_camere=:p17_selectare'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(45516720184972627814)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153136705988536120)
,p_query_column_id=>1
,p_column_alias=>'COD_IMOBIL'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153136810005536121)
,p_query_column_id=>2
,p_column_alias=>'MARIME'
,p_column_display_sequence=>40
,p_column_heading=>'Marime'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153136972830536122)
,p_query_column_id=>3
,p_column_alias=>'ADRESA_IMOBIL'
,p_column_display_sequence=>50
,p_column_heading=>'Adresa Imobil'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153137086841536123)
,p_query_column_id=>4
,p_column_alias=>'COD_LOCALITATE'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153137164947536124)
,p_query_column_id=>5
,p_column_alias=>'COD_TIP_IMOBIL'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153137266718536125)
,p_query_column_id=>6
,p_column_alias=>'COD_CAMERE'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153137353714536126)
,p_query_column_id=>7
,p_column_alias=>'PRET_IMOBIL'
,p_column_display_sequence=>80
,p_column_heading=>'Pret Imobil'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153137457533536127)
,p_query_column_id=>8
,p_column_alias=>'DATA_AFISARE'
,p_column_display_sequence=>90
,p_column_heading=>'Data Afisare'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47153136517284536118)
,p_name=>'P17_SELECTARE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(47153136477071536117)
,p_prompt=>'Selectare nr. camere'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA CAMERELOR'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'N'
);
wwv_flow_imp.component_end;
end;
/
