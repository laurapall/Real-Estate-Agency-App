prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>69163
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>unistr('Agen\021Bie imobiliar\0103')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230129114529'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45516791535078627851)
,p_plug_name=>unistr('Agen\021Bie imobiliar\0103')
,p_icon_css_classes=>'fa-american-sign-language-interpreting'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(45516648584532627786)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45532281586011534704)
,p_plug_name=>'New'
,p_icon_css_classes=>'fa-deafness'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(45516681581063627799)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>unistr('<p> \00CEn aceast\0103 aplica\021Bie pute\021Bi introduce \0219i modifica date respectiv lista \0219i imprima rapoarte. </p> ')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
