prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>69163
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>unistr('Chart agen\021Bi')
,p_alias=>unistr('CHART-AGEN\021AI')
,p_step_title=>unistr('Chart agen\021Bi')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230202142029'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47329291187755656205)
,p_plug_name=>unistr('Agen\021Bi imobiliari')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(45516671789650627795)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P_AGENTI.COD_AGENT as COD_AGENT,',
'(prenume_agent || '' '' || nume_agent) as nume_agent,',
'     P_TIP_IMOBIL.TIP_IMOBIL as TIP_IMOBIL ',
' from P_TIP_IMOBIL P_TIP_IMOBIL,',
'    P_LEGATURI P_LEGATURI,',
'    P_IMOBIL P_IMOBIL,',
'    P_AGENTI P_AGENTI ',
' where P_IMOBIL.COD_TIP_IMOBIL=P_TIP_IMOBIL.COD_TIP_IMOBIL',
'    and P_LEGATURI.COD_IMOBIL=P_IMOBIL.COD_IMOBIL',
'    and P_LEGATURI.COD_AGENT=P_AGENTI.COD_AGENT',
'    order by nume_agent asc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Agen\021Bi imobiliari')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(47329292935715656223)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'PALLLAURA80@GMAIL.COM'
,p_internal_uid=>47329292935715656223
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47329293024372656224)
,p_db_column_name=>'COD_AGENT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cod Agent'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47329293163324656225)
,p_db_column_name=>'NUME_AGENT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nume Agent'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47329293250493656226)
,p_db_column_name=>'TIP_IMOBIL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tip Imobil'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(47398978797114854063)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'473989788'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COD_AGENT:NUME_AGENT:TIP_IMOBIL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47329291702526656211)
,p_plug_name=>unistr('Agen\021Bi - v\00E2nz\0103ri')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(45516681581063627799)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P_AGENTI.COD_AGENT as COD_AGENT,',
'(prenume_agent || '' '' || nume_agent) as nume_agent,',
'     P_TIP_IMOBIL.TIP_IMOBIL as TIP_IMOBIL ',
' from P_TIP_IMOBIL P_TIP_IMOBIL,',
'    P_LEGATURI P_LEGATURI,',
'    P_IMOBIL P_IMOBIL,',
'    P_AGENTI P_AGENTI ',
' where P_IMOBIL.COD_TIP_IMOBIL=P_TIP_IMOBIL.COD_TIP_IMOBIL',
'    and P_LEGATURI.COD_IMOBIL=P_IMOBIL.COD_IMOBIL',
'    and P_LEGATURI.COD_AGENT=P_AGENTI.COD_AGENT',
'    order by nume_agent asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(47329291847518656212)
,p_region_id=>wwv_flow_imp.id(47329291702526656211)
,p_chart_type=>'pie'
,p_title=>unistr('V\00E2nz\0103ri per agen\021Bi')
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_title=>unistr('Nume agen\021Bi ')
,p_legend_position=>'auto'
,p_legend_font_family=>'Times New Roman'
,p_legend_font_style=>'normal'
,p_legend_font_size=>'14'
,p_legend_font_color=>'#000000'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(47329291934408656213)
,p_chart_id=>wwv_flow_imp.id(47329291847518656212)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P_AGENTI.COD_AGENT as COD_AGENT,',
'(prenume_agent || '' '' || nume_agent) as nume_agent,',
'     P_TIP_IMOBIL.TIP_IMOBIL as TIP_IMOBIL ',
' from P_TIP_IMOBIL P_TIP_IMOBIL,',
'    P_LEGATURI P_LEGATURI,',
'    P_IMOBIL P_IMOBIL,',
'    P_AGENTI P_AGENTI ',
' where P_IMOBIL.COD_TIP_IMOBIL=P_TIP_IMOBIL.COD_TIP_IMOBIL',
'    and P_LEGATURI.COD_IMOBIL=P_IMOBIL.COD_IMOBIL',
'    and P_LEGATURI.COD_AGENT=P_AGENTI.COD_AGENT',
'    order by nume_agent asc'))
,p_series_name_column_name=>'NUME_AGENT'
,p_items_value_column_name=>'COD_AGENT'
,p_items_label_column_name=>'NUME_AGENT'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47389810009970183481)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(45516693919594627803)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(45516578886176627756)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(45516756899606627830)
);
wwv_flow_imp.component_end;
end;
/
