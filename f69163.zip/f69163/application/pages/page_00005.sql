prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>69163
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Rapoarte'
,p_alias=>'RAPOARTE'
,p_step_title=>'Rapoarte'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230129125835'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182797943970475170166)
,p_plug_name=>'Rapoarte'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(45516681581063627799)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<h3> Aici pute\021Bi g\0103si rapoarte despre: </h3>'),
'<ul> ',
'<li>   Imobile </li>',
unistr(' <li>  Agen\021Bi </li>'),
unistr(' <li>  Tranzac\021Bii </li>'),
' </ul>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
