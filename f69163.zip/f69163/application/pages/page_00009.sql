prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.1'
,p_default_workspace_id=>56919689394143710057
,p_default_application_id=>69163
,p_default_id_offset=>0
,p_default_owner=>'WKSP_LAURAPALL'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>unistr('Ad\0103ugare date imobil (cu procedur\0103)')
,p_alias=>unistr('AD\0102UGARE-DATE-IMOBIL-CU-PROCEDUR\0102')
,p_step_title=>unistr('Ad\0103ugare date imobil (cu procedur\0103)')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'PALLLAURA80@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230202063538'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47064033409449690873)
,p_plug_name=>unistr('Ad\0103ugare date imobil (cu procedur\0103)')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(45516681581063627799)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(47153138556888536138)
,p_name=>'Lista imobilelor'
,p_template=>wwv_flow_imp.id(45516681581063627799)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select V_IMOBIL.COD_IMOBIL as COD_IMOBIL,',
'    V_IMOBIL.TIP_IMOBIL as TIP_IMOBIL,',
'    V_IMOBIL.NR_CAMERE as NR_CAMERE,',
'    V_IMOBIL.MARIME as MARIME,',
'    V_IMOBIL.ADRESA_IMOBIL as ADRESA_IMOBIL,',
'    V_IMOBIL.LOCALITATE as LOCALITATE,',
'    V_IMOBIL.JUDET as JUDET,',
'    V_IMOBIL.PRET_IMOBIL as PRET_IMOBIL,',
'    V_IMOBIL.DATA_AFISARE as DATA_AFISARE,',
'    V_IMOBIL.NUME_AGENT as NUME_AGENT ',
' from V_IMOBIL V_IMOBIL'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(45516720184972627814)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153138619719536139)
,p_query_column_id=>1
,p_column_alias=>'COD_IMOBIL'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153138706939536140)
,p_query_column_id=>2
,p_column_alias=>'TIP_IMOBIL'
,p_column_display_sequence=>20
,p_column_heading=>'Tip Imobil'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153138858494536141)
,p_query_column_id=>3
,p_column_alias=>'NR_CAMERE'
,p_column_display_sequence=>30
,p_column_heading=>'Nr Camere'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153138908395536142)
,p_query_column_id=>4
,p_column_alias=>'MARIME'
,p_column_display_sequence=>40
,p_column_heading=>'Marime'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153139061360536143)
,p_query_column_id=>5
,p_column_alias=>'ADRESA_IMOBIL'
,p_column_display_sequence=>50
,p_column_heading=>'Adresa Imobil'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153139117610536144)
,p_query_column_id=>6
,p_column_alias=>'LOCALITATE'
,p_column_display_sequence=>60
,p_column_heading=>'Localitate'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153139205013536145)
,p_query_column_id=>7
,p_column_alias=>'JUDET'
,p_column_display_sequence=>70
,p_column_heading=>'Judet'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153139330762536146)
,p_query_column_id=>8
,p_column_alias=>'PRET_IMOBIL'
,p_column_display_sequence=>80
,p_column_heading=>'Pret Imobil'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153139433350536147)
,p_query_column_id=>9
,p_column_alias=>'DATA_AFISARE'
,p_column_display_sequence=>90
,p_column_heading=>'Data Afisare'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47153139531351536148)
,p_query_column_id=>10
,p_column_alias=>'NUME_AGENT'
,p_column_display_sequence=>100
,p_column_heading=>'Nume Agent'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47064033820396690873)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(45516755229229627829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Abandon'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47064033905813690873)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(45516755229229627829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Ad\0103ugare imobil')
,p_button_position=>'CLOSE'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(47064038338789690879)
,p_branch_action=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(47064033905813690873)
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46208292162164440549)
,p_name=>'P9_JUD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>unistr('Jude\021Bul')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>unistr('LISTA JUDE\021AELOR')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064034764533690876)
,p_name=>'P9_RIME1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>unistr('M\0103rime imobil')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064035197558690877)
,p_name=>'P9_RESA1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>unistr('Adres\0103')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064035594941690877)
,p_name=>'P9_DLOC'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>'Localitate'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P_LOCALITATE.LOCALITATE as LOCALITATE,',
'    P_LOCALITATE.COD_LOCALITATE as COD_LOCALITATE ',
' from P_LOCALITATE P_LOCALITATE',
' where COD_JUDET=:P9_JUD'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P9_JUD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064035909765690877)
,p_name=>'P9_DTIP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>'Tipul imobilului'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA TIP IMOBIL'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064036394272690878)
,p_name=>'P9_DCAM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>'Nr. camere'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA CAMERELOR'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064036720423690878)
,p_name=>'P9_DAG'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>'Nume agent'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTAG'
,p_lov=>'	select (prenume_agent || '' '' || nume_agent) as nume_agent, cod_agent from p_agenti order by nume_agent asc'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064037196913690878)
,p_name=>'P9_ET1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>unistr('Pre\021B imobil')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47064037509970690878)
,p_name=>'P9_TA1'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(47064033409449690873)
,p_prompt=>unistr('Data list\0103rii')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(45516752750299627828)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47064037977965690879)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Run Stored Procedure'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'"#OWNER#"."PROC_IMOB_AG"(',
'"MARIME1" => :P9_RIME1,',
'"ADRESA1" => :P9_RESA1,',
'"CODLOC" => :P9_DLOC,',
'"CODTIP" => :P9_DTIP,',
'"CODCAM" => :P9_DCAM,',
'"CODAG" => :P9_DAG,',
'"PRET1" => :P9_ET1,',
'"DATA1" => :P9_TA1);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Nu s-a efectuat introducerea datelor.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(47064033905813690873)
,p_process_success_message=>unistr('Ad\0103ugarea datelor s-a efectuat cu succes. ')
,p_internal_uid=>47064037977965690879
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46208292247474440550)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Golire'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46208292247474440550
);
wwv_flow_imp.component_end;
end;
/
